# **App Name**: Shpe Billing 

## Core Features:

- Item Management: Add, edit, and view inventory items, including product names, individual prices, and current stock quantities.
- Inventory Tracking & Alerts: Automatically track item quantities and display current stock levels. Generate notifications when an item's stock is low or out of stock.
- Bill Creation Workflow: Efficiently search for items, add them to a bill, adjust quantities, and calculate real-time line item and total prices. Capture customer names for each bill.
- AI Product Description Tool: Utilize an AI tool to automatically generate concise and appealing product descriptions for newly added items based on their name or category.
- Bill History & Archiving: Save all generated bills, creating a searchable history for past transactions, including customer details and itemized lists.
- Printable Receipt Generation: Produce a formatted, printable receipt for any selected bill from the history, ready for physical printing.

## Style Guidelines:

- The overall interface employs a light color scheme to convey cleanliness and clarity. The primary color is a sophisticated, muted blue (#335999), reflecting professionalism and reliability. The background color is a very light, subtle off-white with a hint of blue (#EFF1F4), maintaining visual lightness. An accent color, a bright cyan-blue (#44D1EB), is used to highlight interactive elements and calls to action, creating a refreshing contrast.
- The font for both headlines and body text is 'Inter', a grotesque-style sans-serif known for its modern, objective, and highly readable appearance, ideal for a professional billing application with detailed information.
- Utilize simple, clean, and functional icons with clear outlines. Prioritize icons that directly communicate their purpose, enhancing navigability without visual clutter. Examples include shopping cart for bill creation, archive box for history, and printer icon for receipt generation.
- The layout features a clean, organized, and spacious design, ensuring critical information such as item details, quantities, and totals are easily digestible. Key interactive elements are prominently placed for efficient workflow, with adequate white space to reduce visual fatigue.
- Subtle and functional animations are applied sparingly, primarily for feedback on user actions. Examples include smooth transitions when adding items to a bill, slight highlight effects on buttons upon hover, and a gentle fade-in for notifications like 'item out of stock'.