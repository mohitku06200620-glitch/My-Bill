
import { Product, Bill } from './types';

// Initial Mock Data
const INITIAL_PRODUCTS: Product[] = [
  { id: '1', name: 'Premium Coffee Beans', category: 'Groceries', description: 'Freshly roasted arabica beans.', price: 15.99, stock: 25 },
  { id: '2', name: 'Organic Honey', category: 'Groceries', description: 'Pure wildflower honey.', price: 12.50, stock: 5 },
  { id: '3', name: 'Cotton T-Shirt', category: 'Apparel', description: 'Soft 100% cotton casual wear.', price: 19.99, stock: 50 },
  { id: '4', name: 'Running Shoes', category: 'Footwear', description: 'Lightweight breathable mesh shoes.', price: 89.90, stock: 0 },
];

export const getProducts = (): Product[] => {
  if (typeof window === 'undefined') return INITIAL_PRODUCTS;
  const saved = localStorage.getItem('sope_products');
  return saved ? JSON.parse(saved) : INITIAL_PRODUCTS;
};

export const saveProducts = (products: Product[]) => {
  localStorage.setItem('sope_products', JSON.stringify(products));
};

export const getBills = (): Bill[] => {
  if (typeof window === 'undefined') return [];
  const saved = localStorage.getItem('sope_bills');
  return saved ? JSON.parse(saved) : [];
};

export const saveBills = (bills: Bill[]) => {
  localStorage.setItem('sope_bills', JSON.stringify(bills));
};
