
export interface Product {
  id: string;
  name: string;
  category: string;
  description: string;
  price: number;
  stock: number;
}

export interface BillItem {
  productId: string;
  name: string;
  quantity: number;
  price: number;
}

export interface Bill {
  id: string;
  customerName: string;
  date: string;
  items: BillItem[];
  subtotal: number;
  discountPercentage: number;
  discountAmount: number;
  total: number;
}

export interface UserProfile {
  displayName: string;
}
