
"use client";

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword 
} from 'firebase/auth';
import { useAuth, useUser } from '@/firebase';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardFooter, CardDescription } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { Receipt, Loader2, Info, ArrowRight, AlertCircle } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isRegistering, setIsRegistering] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);
  
  const auth = useAuth();
  const { user, loading: userLoading, isGuest } = useUser();
  const router = useRouter();
  const { toast } = useToast();

  useEffect(() => {
    if (!userLoading && user && !isGuest) {
      router.push('/dashboard');
    }
  }, [user, userLoading, isGuest, router]);

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    
    if (!auth) {
      toast({ 
        variant: "destructive", 
        title: "Auth Not Initialized", 
        description: "Firebase Authentication is not ready." 
      });
      return;
    }
    
    setIsLoading(true);
    try {
      if (isRegistering) {
        await createUserWithEmailAndPassword(auth, email, password);
        toast({ title: "Success!", description: "Account created successfully." });
      } else {
        await signInWithEmailAndPassword(auth, email, password);
        toast({ title: "Welcome back", description: "Signed in successfully." });
      }
      router.push('/dashboard');
    } catch (error: any) {
      // Clean up error message for display
      let message = error.message || "Authentication failed.";
      
      // Specifically handle the "blocked" or "operation-not-allowed" errors
      const isConfigError = error.message?.includes('identitytoolkit') || 
                            error.code === 'auth/operation-not-allowed';

      if (isConfigError) {
        setAuthError("Email/Password provider setup detected an issue. If you just enabled it in the console, please wait a minute or refresh. Ensure you enabled it for project: studio-7545740065-53c2c");
      } else if (error.code === 'auth/invalid-credential') {
        setAuthError("Invalid email or password.");
      } else if (error.code === 'auth/email-already-in-use') {
        setAuthError("This email is already registered. Try signing in.");
      } else if (error.code === 'auth/weak-password') {
        setAuthError("Password should be at least 6 characters.");
      } else {
        setAuthError(message);
      }
      
      toast({ 
        variant: "destructive", 
        title: "Authentication Failed", 
        description: "Please check the error message on the screen." 
      });
    } finally {
      setIsLoading(false);
    }
  };

  if (userLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-background p-4 space-y-6">
      <Card className="w-full max-w-[400px] shadow-xl border-primary/20">
        <CardHeader className="space-y-1 text-center">
          <div className="flex justify-center mb-4">
            <div className="bg-primary p-3 rounded-2xl">
              <Receipt className="h-8 w-8 text-primary-foreground" />
            </div>
          </div>
          <CardTitle className="text-2xl font-bold font-headline text-primary">BillForge</CardTitle>
          <CardDescription>
            {isRegistering ? 'Create a new account' : 'Sign in to your shop'}
          </CardDescription>
        </CardHeader>
        <form onSubmit={handleAuth}>
          <CardContent className="space-y-4">
            {authError && (
              <Alert variant="destructive" className="bg-destructive/5 text-destructive border-destructive/20">
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>Notice</AlertTitle>
                <AlertDescription className="text-xs">
                  {authError}
                </AlertDescription>
              </Alert>
            )}

            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input 
                id="email" 
                type="email" 
                placeholder="you@example.com" 
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required 
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input 
                id="password" 
                type="password" 
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required 
              />
            </div>
          </CardContent>
          <CardFooter className="flex flex-col gap-4">
            <Button className="w-full h-11" type="submit" disabled={isLoading}>
              {isLoading ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
              {isRegistering ? 'Register & Log In' : 'Sign In'}
            </Button>
            
            <div className="flex flex-col items-center gap-2 w-full">
              <button 
                type="button"
                className="text-sm text-primary hover:underline font-medium"
                onClick={() => {
                  setIsRegistering(!isRegistering);
                  setAuthError(null);
                }}
              >
                {isRegistering ? 'Already have an account? Sign In' : "Don't have an account? Sign Up"}
              </button>
              
              <div className="flex items-center gap-2 w-full my-2">
                <div className="h-[1px] bg-border flex-1"></div>
                <span className="text-[10px] text-muted-foreground uppercase tracking-widest font-bold">or</span>
                <div className="h-[1px] bg-border flex-1"></div>
              </div>

              <Button 
                type="button" 
                variant="ghost" 
                className="w-full text-muted-foreground hover:text-primary gap-2"
                onClick={() => router.push('/dashboard')}
              >
                Continue as Guest <ArrowRight className="h-4 w-4" />
              </Button>
            </div>
          </CardFooter>
        </form>
      </Card>
      
      <p className="text-[10px] text-muted-foreground text-center max-w-[300px]">
        Secure your inventory and access it from any device by creating a free account.
      </p>
    </div>
  );
}
