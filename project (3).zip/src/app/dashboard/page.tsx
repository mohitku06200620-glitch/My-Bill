
"use client";

import React, { useState, useEffect, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { collection, doc } from 'firebase/firestore';
import { useFirestore, useUser, useCollection, useDoc } from '@/firebase';
import { Product, Bill, UserProfile } from '@/lib/types';
import { 
  TrendingUp, 
  Package, 
  AlertTriangle, 
  Users,
  Clock,
  Calendar as CalendarIcon,
  User as UserIcon,
  LogIn
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import { cn } from '@/lib/utils';
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';

export default function OverviewPage() {
  const { user, isGuest } = useUser();
  const db = useFirestore();
  const [currentTime, setCurrentTime] = useState<string>("");
  const [currentDate, setCurrentDate] = useState<string>("");
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
      setCurrentDate(now.toLocaleDateString([], { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }));
    };
    updateTime();
    const timer = setInterval(updateTime, 1000);
    return () => clearInterval(timer);
  }, []);

  const productsQuery = useMemo(() => {
    if (!db || !user) return null;
    return collection(db, 'users', user.uid, 'products');
  }, [db, user]);

  const billsQuery = useMemo(() => {
    if (!db || !user) return null;
    return collection(db, 'users', user.uid, 'bills');
  }, [db, user]);

  const profileRef = useMemo(() => {
    if (!db || !user) return null;
    return doc(db, 'users', user.uid, 'profile', 'data');
  }, [db, user]);

  const { data: products = [] } = useCollection(productsQuery) as { data: Product[] };
  const { data: bills = [] } = useCollection(billsQuery) as { data: Bill[] };
  const { data: profile } = useDoc(profileRef) as { data: UserProfile | null };

  const todayStr = mounted ? new Date().toISOString().split('T')[0] : "";
  
  const todayBills = bills.filter(b => b.date.startsWith(todayStr));
  const todayRevenue = todayBills.reduce((acc, b) => acc + b.total, 0);
  const totalRevenue = bills.reduce((acc, b) => acc + b.total, 0);

  const lowStock = products.filter(p => p.stock > 0 && p.stock < 10).length;
  const outOfStock = products.filter(p => p.stock === 0).length;
  const totalItems = products.length;

  const defaultUserName = isGuest ? 'Guest' : (user?.email?.split('@')[0] || 'User');
  const userName = profile?.displayName || defaultUserName;

  if (!mounted) return null;

  return (
    <div className="space-y-8">
      {isGuest && (
        <Alert className="bg-primary/5 border-primary/20">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between w-full gap-4">
            <div className="flex items-center gap-3">
              <div className="bg-primary/10 p-2 rounded-full">
                <UserIcon className="h-5 w-5 text-primary" />
              </div>
              <div>
                <AlertTitle className="font-bold text-primary">Guest Mode Active</AlertTitle>
                <AlertDescription className="text-muted-foreground">
                  Your data is saved under a guest profile. <strong>Log in</strong> to secure your inventory and access it from any device.
                </AlertDescription>
              </div>
            </div>
            <Button asChild className="shrink-0 bg-primary hover:bg-primary/90">
              <Link href="/login">
                <LogIn className="h-4 w-4 mr-2" /> Log In / Sign Up
              </Link>
            </Button>
          </div>
        </Alert>
      )}

      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold font-headline text-primary">Shop Overview</h2>
          <p className="text-muted-foreground mt-1">Welcome back, {userName}</p>
        </div>
        <Card className="border-accent/20 bg-accent/5 py-2 px-4 shadow-sm">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 text-primary">
              <Clock className="h-4 w-4" />
              <span className="font-mono font-bold text-lg">{currentTime}</span>
            </div>
            <div className="h-4 w-[1px] bg-border" />
            <div className="flex items-center gap-2 text-muted-foreground">
              <CalendarIcon className="h-4 w-4" />
              <span className="text-sm font-medium">{currentDate}</span>
            </div>
          </div>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card className="border-emerald-100 bg-emerald-50/30">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Today's Revenue</CardTitle>
            <TrendingUp className="h-4 w-4 text-emerald-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-emerald-700">₹{todayRevenue.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">Total: ₹{totalRevenue.toFixed(2)}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Products</CardTitle>
            <Package className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalItems}</div>
            <p className="text-xs text-muted-foreground">Across {new Set(products.map(p => p.category)).size} categories</p>
          </CardContent>
        </Card>
        <Card className={cn(lowStock + outOfStock > 0 ? "border-destructive/20 bg-destructive/5" : "")}>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Inventory Alerts</CardTitle>
            <AlertTriangle className={cn("h-4 w-4", lowStock + outOfStock > 0 ? "text-destructive" : "text-muted-foreground")} />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{lowStock + outOfStock}</div>
            <p className="text-xs text-muted-foreground">
              {outOfStock} items out of stock
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Bills Generated</CardTitle>
            <Users className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{bills.length}</div>
            <p className="text-xs text-muted-foreground">Life-time transactions</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card className="col-span-1">
          <CardHeader>
            <CardTitle>Recent Sales</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {bills.slice().reverse().slice(0, 5).map((bill) => (
                <div key={bill.id} className="flex items-center justify-between border-b pb-3 last:border-0 last:pb-0">
                  <div>
                    <p className="text-sm font-medium">{bill.customerName || 'Walk-in Customer'}</p>
                    <p className="text-xs text-muted-foreground">{new Date(bill.date).toLocaleString()}</p>
                  </div>
                  <div className="text-sm font-bold text-primary">+₹{bill.total.toFixed(2)}</div>
                </div>
              ))}
              {bills.length === 0 && <p className="text-sm text-muted-foreground">No sales yet.</p>}
            </div>
            <Button asChild variant="link" className="mt-4 p-0">
              <Link href="/dashboard/history">View all history</Link>
            </Button>
          </CardContent>
        </Card>

        <Card className="col-span-1 border-destructive/20 bg-destructive/5">
          <CardHeader>
            <CardTitle className="text-destructive flex items-center gap-2">
              <AlertTriangle className="h-5 w-5" /> Critical Stock Alerts
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {products.filter(p => p.stock < 5).map((p) => (
                <div key={p.id} className="flex items-center justify-between border-b border-destructive/10 pb-3 last:border-0 last:pb-0">
                  <div>
                    <p className="text-sm font-medium">{p.name}</p>
                    <p className="text-xs text-destructive">{p.stock === 0 ? 'OUT OF STOCK' : `Only ${p.stock} units left`}</p>
                  </div>
                  <Button size="sm" variant="outline" asChild>
                    <Link href="/dashboard/inventory">Manage</Link>
                  </Button>
                </div>
              ))}
              {products.filter(p => p.stock < 5).length === 0 && <p className="text-sm text-muted-foreground">All stock levels are healthy.</p>}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
