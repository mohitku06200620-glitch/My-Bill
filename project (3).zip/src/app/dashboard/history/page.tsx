
"use client";

import React, { useState, useMemo, useEffect } from 'react';
import { collection, query, orderBy } from 'firebase/firestore';
import { useFirestore, useUser, useCollection } from '@/firebase';
import { Bill } from '@/lib/types';
import { 
  Search, 
  Eye, 
  Printer, 
  User,
  Loader2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Separator } from '@/components/ui/separator';

export default function HistoryPage() {
  const { user } = useUser();
  const db = useFirestore();
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  const billsQuery = useMemo(() => {
    if (!db || !user) return null;
    return query(collection(db, 'users', user.uid, 'bills'), orderBy('date', 'desc'));
  }, [db, user]);

  const { data: bills = [], loading } = useCollection(billsQuery) as { data: Bill[], loading: boolean };

  const [search, setSearch] = useState('');
  const [selectedBill, setSelectedBill] = useState<Bill | null>(null);
  const [isPreviewOpen, setIsPreviewOpen] = useState(false);

  const filteredBills = bills.filter(b => 
    b.customerName.toLowerCase().includes(search.toLowerCase()) ||
    b.id.toLowerCase().includes(search.toLowerCase())
  );

  const openPreview = (bill: Bill) => {
    setSelectedBill(bill);
    setIsPreviewOpen(true);
  };

  const printReceipt = () => {
    window.print();
  };

  if (!mounted) return null;

  return (
    <div className="space-y-6">
      <div className="no-print">
        <h2 className="text-3xl font-bold font-headline text-primary">Transaction History</h2>
        <p className="text-muted-foreground mt-1">View past bills and generate reprints.</p>
      </div>

      <div className="no-print flex items-center gap-2 bg-card p-3 rounded-lg border shadow-sm">
        <Search className="h-4 w-4 text-muted-foreground ml-2" />
        <Input 
          placeholder="Search by customer name or invoice ID..." 
          className="border-0 focus-visible:ring-0 shadow-none"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      <div className="no-print bg-card rounded-lg border shadow-sm overflow-hidden">
        <Table>
          <TableHeader className="bg-secondary/50">
            <TableRow>
              <TableHead>Invoice ID</TableHead>
              <TableHead>Customer</TableHead>
              <TableHead>Date</TableHead>
              <TableHead>Total Items</TableHead>
              <TableHead>Amount</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              <TableRow>
                <TableCell colSpan={6} className="h-32 text-center text-muted-foreground">
                  <Loader2 className="h-8 w-8 animate-spin mx-auto mb-2" />
                  Loading history...
                </TableCell>
              </TableRow>
            ) : filteredBills.map((bill) => (
              <TableRow key={bill.id}>
                <TableCell className="font-mono text-xs font-bold text-primary">{bill.id}</TableCell>
                <TableCell>
                  <div className="font-medium">{bill.customerName}</div>
                </TableCell>
                <TableCell className="text-sm text-muted-foreground">
                  {new Date(bill.date).toLocaleDateString()}
                </TableCell>
                <TableCell>
                  {bill.items.length} items
                </TableCell>
                <TableCell className="font-bold">₹{bill.total.toFixed(2)}</TableCell>
                <TableCell className="text-right">
                  <Button variant="outline" size="sm" onClick={() => openPreview(bill)}>
                    <Eye className="h-4 w-4 mr-2" /> View Bill
                  </Button>
                </TableCell>
              </TableRow>
            ))}
            {!loading && filteredBills.length === 0 && (
              <TableRow>
                <TableCell colSpan={6} className="h-32 text-center text-muted-foreground">
                  No transaction history found.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      {selectedBill && (
        <div className="print-only fixed inset-0 bg-white p-8">
           <div className="max-w-md mx-auto border p-8 space-y-6">
            <div className="text-center">
              <h1 className="text-3xl font-bold uppercase">Sope BillForge</h1>
              <p className="text-sm text-gray-500">Shop Receipt</p>
            </div>
            
            <Separator />
            
            <div className="flex justify-between text-sm">
              <div>
                <p className="font-bold uppercase text-xs text-gray-400">Invoice To:</p>
                <p className="font-bold">{selectedBill.customerName}</p>
              </div>
              <div className="text-right">
                <p className="font-bold uppercase text-xs text-gray-400">Invoice Details:</p>
                <p className="font-medium">#{selectedBill.id}</p>
                <p className="text-xs">{new Date(selectedBill.date).toLocaleString()}</p>
              </div>
            </div>

            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="px-0">Item</TableHead>
                  <TableHead className="text-center px-0">Qty</TableHead>
                  <TableHead className="text-right px-0">Price</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {selectedBill.items.map((item, idx) => (
                  <TableRow key={idx} className="border-b last:border-0">
                    <TableCell className="px-0 py-2">{item.name}</TableCell>
                    <TableCell className="text-center px-0 py-2">{item.quantity}</TableCell>
                    <TableCell className="text-right px-0 py-2">₹{(item.price * item.quantity).toFixed(2)}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>

            <Separator />

            <div className="space-y-1">
              <div className="flex justify-between text-xs">
                <span>Subtotal</span>
                <span>₹{(selectedBill.subtotal || selectedBill.total).toFixed(2)}</span>
              </div>
              {selectedBill.discountPercentage > 0 && (
                <div className="flex justify-between text-xs text-gray-600">
                  <span>Discount ({selectedBill.discountPercentage}%)</span>
                  <span>-₹{selectedBill.discountAmount.toFixed(2)}</span>
                </div>
              )}
              <div className="flex justify-between items-center pt-2">
                <span className="text-xl font-bold">TOTAL</span>
                <span className="text-2xl font-black">₹{selectedBill.total.toFixed(2)}</span>
              </div>
            </div>

            <Separator />

            <div className="text-center space-y-2 py-4">
              <p className="text-sm font-medium italic">Thank you for shopping with us!</p>
            </div>
          </div>
        </div>
      )}

      <Dialog open={isPreviewOpen} onOpenChange={setIsPreviewOpen}>
        <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Printer className="h-5 w-5" /> Bill Preview - {selectedBill?.id}
            </DialogTitle>
          </DialogHeader>
          
          {selectedBill && (
            <div className="space-y-6 py-4">
              <div className="flex justify-between items-start">
                <div className="space-y-1">
                  <h3 className="text-2xl font-bold text-primary">Sope BillForge</h3>
                  <p className="text-xs text-muted-foreground">Smart Inventory & Billing</p>
                </div>
                <div className="text-right space-y-1">
                  <Badge variant="secondary" className="font-mono">{selectedBill.id}</Badge>
                  <p className="text-sm font-medium text-muted-foreground">{new Date(selectedBill.date).toLocaleString()}</p>
                </div>
              </div>

              <div className="bg-secondary/30 p-4 rounded-lg flex items-center gap-4">
                <div className="bg-primary/10 p-2 rounded-full">
                  <User className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="text-xs uppercase text-muted-foreground font-bold tracking-wider">Customer Name</p>
                  <p className="text-lg font-bold">{selectedBill.customerName}</p>
                </div>
              </div>

              <div className="border rounded-lg overflow-hidden">
                <Table>
                  <TableHeader className="bg-secondary/50">
                    <TableRow>
                      <TableHead>Item Details</TableHead>
                      <TableHead className="text-center">Qty</TableHead>
                      <TableHead className="text-right">Price</TableHead>
                      <TableHead className="text-right">Subtotal</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {selectedBill.items.map((item, idx) => (
                      <TableRow key={idx}>
                        <TableCell className="font-medium">{item.name}</TableCell>
                        <TableCell className="text-center">{item.quantity}</TableCell>
                        <TableCell className="text-right">₹{item.price.toFixed(2)}</TableCell>
                        <TableCell className="text-right font-bold">₹{(item.price * item.quantity).toFixed(2)}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              <div className="flex justify-end pr-4">
                <div className="w-full max-w-[240px] space-y-2">
                  <div className="flex justify-between text-muted-foreground text-sm">
                    <span>Subtotal</span>
                    <span>₹{(selectedBill.subtotal || selectedBill.total).toFixed(2)}</span>
                  </div>
                  {selectedBill.discountPercentage > 0 && (
                    <div className="flex justify-between text-emerald-600 text-sm font-medium">
                      <span>Discount ({selectedBill.discountPercentage}%)</span>
                      <span>-₹{selectedBill.discountAmount.toFixed(2)}</span>
                    </div>
                  )}
                  <Separator />
                  <div className="flex justify-between text-xl font-bold text-primary">
                    <span>Total</span>
                    <span>₹{selectedBill.total.toFixed(2)}</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setIsPreviewOpen(false)}>Close</Button>
            <Button onClick={printReceipt} className="bg-primary">
              <Printer className="h-4 w-4 mr-2" /> Print Receipt
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
