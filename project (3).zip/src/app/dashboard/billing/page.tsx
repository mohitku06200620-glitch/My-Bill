
"use client";

import React, { useState, useMemo } from 'react';
import { doc, setDoc, collection } from 'firebase/firestore';
import { useFirestore, useUser, useCollection } from '@/firebase';
import { Product, Bill, BillItem } from '@/lib/types';
import { 
  Search, 
  ShoppingCart, 
  Trash2, 
  User,
  Plus,
  Minus,
  CheckCircle2,
  Loader2,
  Percent
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { Separator } from '@/components/ui/separator';
import { Label } from '@/components/ui/label';
import { cn } from '@/lib/utils';
import { errorEmitter } from '@/firebase/error-emitter';
import { FirestorePermissionError } from '@/firebase/errors';

export default function BillingPage() {
  const { user } = useUser();
  const db = useFirestore();
  const { toast } = useToast();

  const productsQuery = useMemo(() => {
    if (!db || !user) return null;
    return collection(db, 'users', user.uid, 'products');
  }, [db, user]);

  const { data: products = [], loading } = useCollection(productsQuery) as { data: Product[], loading: boolean };

  const [search, setSearch] = useState('');
  const [customerName, setCustomerName] = useState('');
  const [discountPercent, setDiscountPercent] = useState<number>(0);
  const [cart, setCart] = useState<BillItem[]>([]);

  const filteredProducts = products.filter(p => 
    p.name.toLowerCase().includes(search.toLowerCase()) && p.stock > 0
  );

  const addToCart = (product: Product) => {
    const existing = cart.find(item => item.productId === product.id);
    if (existing) {
      if (existing.quantity >= product.stock) {
        toast({ title: "Out of Stock", description: "Cannot add more than available stock.", variant: "destructive" });
        return;
      }
      setCart(cart.map(item => 
        item.productId === product.id 
          ? { ...item, quantity: item.quantity + 1 } 
          : item
      ));
    } else {
      setCart([...cart, { 
        productId: product.id, 
        name: product.name, 
        quantity: 1, 
        price: product.price 
      }]);
    }
  };

  const updateQuantity = (productId: string, delta: number) => {
    const product = products.find(p => p.id === productId);
    if (!product) return;

    setCart(cart.map(item => {
      if (item.productId === productId) {
        const newQty = item.quantity + delta;
        if (newQty <= 0) return null;
        if (newQty > product.stock) {
          toast({ title: "Stock Limit", description: "Not enough stock available.", variant: "destructive" });
          return item;
        }
        return { ...item, quantity: newQty };
      }
      return item;
    }).filter(Boolean) as BillItem[]);
  };

  const removeFromCart = (productId: string) => {
    setCart(cart.filter(item => item.productId !== productId));
  };

  const subtotal = cart.reduce((acc, item) => acc + (item.price * item.quantity), 0);
  const discountAmount = (subtotal * discountPercent) / 100;
  const total = subtotal - discountAmount;

  const checkout = () => {
    if (!db || !user) return;
    if (cart.length === 0) {
      toast({ title: "Empty Cart", description: "Add items to generate a bill." });
      return;
    }

    const billId = `INV-${Date.now()}`;
    const billRef = doc(db, 'users', user.uid, 'bills', billId);

    const newBill: Bill = {
      id: billId,
      customerName: customerName || 'Walk-in Customer',
      date: new Date().toISOString(),
      items: cart,
      subtotal: subtotal,
      discountPercentage: discountPercent,
      discountAmount: discountAmount,
      total: total
    };

    // 1. Save the bill
    setDoc(billRef, newBill)
      .catch(async (error) => {
        errorEmitter.emit('permission-error', new FirestorePermissionError({
          path: billRef.path,
          operation: 'create',
          requestResourceData: newBill
        }));
      });

    // 2. Update stock for each product in cart
    cart.forEach(item => {
      const product = products.find(p => p.id === item.productId);
      if (product) {
        const productRef = doc(db, 'users', user.uid, 'products', product.id);
        const updatedStock = product.stock - item.quantity;
        setDoc(productRef, { stock: updatedStock }, { merge: true })
          .catch(async (error) => {
             errorEmitter.emit('permission-error', new FirestorePermissionError({
                path: productRef.path,
                operation: 'update',
                requestResourceData: { stock: updatedStock }
              }));
          });
      }
    });
    
    toast({ 
      title: "Bill Generated", 
      description: `Invoice ${newBill.id} saved successfully.`
    });

    // Reset UI
    setCart([]);
    setCustomerName('');
    setSearch('');
    setDiscountPercent(0);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      <div className="lg:col-span-2 space-y-6">
        <div>
          <h2 className="text-3xl font-bold font-headline text-primary">Create Bill</h2>
          <p className="text-muted-foreground mt-1">Search and add items to the current session.</p>
        </div>

        <div className="bg-card p-4 rounded-lg border shadow-sm flex items-center gap-2">
          <Search className="h-5 w-5 text-muted-foreground" />
          <Input 
            placeholder="Search products to add..." 
            className="border-0 focus-visible:ring-0 shadow-none text-lg"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {loading ? (
             <div className="col-span-full py-12 text-center text-muted-foreground">
              <Loader2 className="h-8 w-8 animate-spin mx-auto mb-2" />
              Loading products...
            </div>
          ) : filteredProducts.map((product) => (
            <Card key={product.id} className="cursor-pointer hover:border-accent transition-colors" onClick={() => addToCart(product)}>
              <CardContent className="p-4 flex justify-between items-center">
                <div>
                  <h4 className="font-bold text-lg">{product.name}</h4>
                  <p className="text-sm text-muted-foreground">{product.category}</p>
                  <div className="mt-2 text-primary font-bold text-xl">₹{product.price.toFixed(2)}</div>
                </div>
                <div className="text-right">
                  <div className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Stock</div>
                  <div className={cn(
                    "font-bold px-2 py-1 rounded text-sm",
                    product.stock < 10 ? "bg-amber-100 text-amber-700" : "bg-emerald-100 text-emerald-700"
                  )}>
                    {product.stock} Units
                  </div>
                  <Button size="sm" variant="secondary" className="mt-3">
                    Add <Plus className="h-3 w-3 ml-1" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
          {!loading && search && filteredProducts.length === 0 && (
            <div className="col-span-full py-12 text-center text-muted-foreground">
              No matching items in stock.
            </div>
          )}
        </div>
      </div>

      <div className="lg:col-span-1">
        <Card className="sticky top-24 border-primary/20 shadow-lg">
          <CardHeader className="bg-primary/5">
            <CardTitle className="flex items-center gap-2">
              <ShoppingCart className="h-5 w-5 text-primary" /> Current Bill
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6 space-y-6">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label className="text-xs uppercase text-muted-foreground">Customer Name</Label>
                <div className="flex items-center gap-2 border rounded-md px-3 bg-background">
                  <User className="h-4 w-4 text-muted-foreground" />
                  <Input 
                    placeholder="Enter customer name..." 
                    className="border-0 focus-visible:ring-0 shadow-none"
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label className="text-xs uppercase text-muted-foreground">Discount (%)</Label>
                <div className="flex items-center gap-2 border rounded-md px-3 bg-background">
                  <Percent className="h-4 w-4 text-muted-foreground" />
                  <Input 
                    type="number"
                    min="0"
                    max="100"
                    placeholder="Discount percentage..." 
                    className="border-0 focus-visible:ring-0 shadow-none"
                    value={discountPercent}
                    onChange={(e) => setDiscountPercent(Math.min(100, Math.max(0, parseFloat(e.target.value) || 0)))}
                  />
                </div>
              </div>
            </div>

            <Separator />

            <div className="space-y-4 max-h-[400px] overflow-auto pr-2">
              {cart.map((item) => (
                <div key={item.productId} className="flex justify-between items-start">
                  <div className="flex-1">
                    <p className="font-medium">{item.name}</p>
                    <p className="text-xs text-muted-foreground">₹{item.price.toFixed(2)} / unit</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="flex items-center border rounded-md overflow-hidden">
                      <button onClick={() => updateQuantity(item.productId, -1)} className="p-1 px-2 hover:bg-secondary"><Minus className="h-3 w-3" /></button>
                      <span className="px-2 text-sm font-bold min-w-[20px] text-center">{item.quantity}</span>
                      <button onClick={() => updateQuantity(item.productId, 1)} className="p-1 px-2 hover:bg-secondary"><Plus className="h-3 w-3" /></button>
                    </div>
                    <button onClick={() => removeFromCart(item.productId)} className="text-destructive hover:bg-destructive/10 p-1 rounded">
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              ))}
              {cart.length === 0 && (
                <div className="text-center py-8 text-muted-foreground">
                  <p>Cart is empty</p>
                  <p className="text-xs mt-1">Add items from the left list</p>
                </div>
              )}
            </div>

            <Separator />

            <div className="space-y-2">
              <div className="flex justify-between text-sm text-muted-foreground">
                <span>Subtotal</span>
                <span>₹{subtotal.toFixed(2)}</span>
              </div>
              {discountPercent > 0 && (
                <div className="flex justify-between text-sm text-emerald-600 font-medium">
                  <span>Discount ({discountPercent}%)</span>
                  <span>-₹{discountAmount.toFixed(2)}</span>
                </div>
              )}
              <div className="flex justify-between text-lg font-bold text-primary">
                <span>Total Amount</span>
                <span>₹{total.toFixed(2)}</span>
              </div>
            </div>
          </CardContent>
          <CardFooter className="bg-primary/5 p-6 border-t">
            <Button onClick={checkout} className="w-full h-12 text-lg bg-primary hover:bg-primary/90 shadow-md">
              <CheckCircle2 className="h-5 w-5 mr-2" /> Complete Bill & Save
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}
