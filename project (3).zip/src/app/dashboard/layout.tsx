
"use client";

import React, { useMemo, useState, useEffect } from 'react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { 
  LayoutDashboard, 
  Package, 
  Receipt, 
  History, 
  Bell,
  User as UserIcon,
  LogIn,
  LogOut,
  Menu,
  Edit2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { 
  SidebarProvider, 
  Sidebar, 
  SidebarContent, 
  SidebarHeader, 
  SidebarMenu, 
  SidebarMenuItem, 
  SidebarMenuButton, 
  SidebarGroup, 
  SidebarGroupLabel,
  SidebarFooter,
  SidebarTrigger
} from '@/components/ui/sidebar';
import { 
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription
} from "@/components/ui/dialog";
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useUser, useAuth, useFirestore, useDoc } from '@/firebase';
import { signOut } from 'firebase/auth';
import { doc, setDoc } from 'firebase/firestore';
import { UserProfile } from '@/lib/types';
import { errorEmitter } from '@/firebase/error-emitter';
import { FirestorePermissionError } from '@/firebase/errors';
import { useToast } from '@/hooks/use-toast';

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();
  const { user, loading, isGuest } = useUser();
  const auth = useAuth();
  const db = useFirestore();
  const { toast } = useToast();

  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [newDisplayName, setNewDisplayName] = useState('');

  const profileRef = useMemo(() => {
    if (!db || !user) return null;
    return doc(db, 'users', user.uid, 'profile', 'data');
  }, [db, user]);

  const { data: profile } = useDoc(profileRef) as { data: UserProfile | null };

  useEffect(() => {
    if (!loading && !user) {
      router.push('/login');
    }
  }, [user, loading, router]);

  const handleLogout = async () => {
    if (auth) {
      await signOut(auth);
      router.push('/login');
    }
  };

  const handleSaveProfile = () => {
    if (!db || !user || !newDisplayName.trim()) return;
    
    const data = { displayName: newDisplayName };
    setDoc(profileRef!, data, { merge: true })
      .catch(async (error) => {
        errorEmitter.emit('permission-error', new FirestorePermissionError({
          path: profileRef!.path,
          operation: 'write',
          requestResourceData: data
        }));
      });
    
    setIsEditDialogOpen(false);
    toast({ title: "Profile Updated" });
  };

  if (loading || !user) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-background">
        <div className="flex flex-col items-center gap-4">
          <div className="h-10 w-10 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
          <p className="text-primary font-bold">Loading BillForge...</p>
        </div>
      </div>
    );
  }

  const navItems = [
    { name: 'Overview', href: '/dashboard', icon: LayoutDashboard },
    { name: 'Inventory', href: '/dashboard/inventory', icon: Package },
    { name: 'New Bill', href: '/dashboard/billing', icon: Receipt },
    { name: 'History', href: '/dashboard/history', icon: History },
  ];

  const defaultUserName = isGuest ? 'Guest Store' : (user?.email?.split('@')[0] || 'User');
  const userInitials = (profile?.displayName || defaultUserName).substring(0, 2).toUpperCase();
  const userName = profile?.displayName || defaultUserName;

  return (
    <SidebarProvider>
      <div className="flex min-h-screen w-full bg-background">
        <Sidebar>
          <SidebarHeader className="p-6">
            <div className="flex items-center gap-2">
              <div className="bg-primary p-2 rounded-lg">
                <Receipt className="text-primary-foreground h-6 w-6" />
              </div>
              <h1 className="text-xl font-bold font-headline tracking-tight text-primary">BillForge</h1>
            </div>
          </SidebarHeader>
          <SidebarContent>
            <SidebarGroup>
              <SidebarGroupLabel>Menu</SidebarGroupLabel>
              <SidebarMenu>
                {navItems.map((item) => (
                  <SidebarMenuItem key={item.name}>
                    <SidebarMenuButton asChild isActive={pathname === item.href}>
                      <Link href={item.href} className="flex items-center gap-3">
                        <item.icon className="h-4 w-4" />
                        <span>{item.name}</span>
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                ))}
              </SidebarMenu>
            </SidebarGroup>
          </SidebarContent>
          <SidebarFooter className="p-4 border-t bg-primary/5">
            <div className="space-y-4">
              <div className="flex items-center gap-3 w-full overflow-hidden group/name">
                <div className="h-8 w-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold text-xs shrink-0 uppercase">
                  {userInitials}
                </div>
                <div className="flex-1 overflow-hidden">
                  <div className="flex items-center gap-1">
                    <p className="text-xs font-bold truncate">{userName}</p>
                    <button 
                      onClick={() => {
                        setNewDisplayName(userName);
                        setIsEditDialogOpen(true);
                      }}
                      className="opacity-0 group-hover/name:opacity-100 transition-opacity"
                    >
                      <Edit2 className="h-3 w-3 text-muted-foreground hover:text-primary" />
                    </button>
                  </div>
                  <p className="text-[10px] text-muted-foreground truncate">{isGuest ? 'Local Access' : user?.email}</p>
                </div>
              </div>
              
              {isGuest ? (
                <Button asChild variant="outline" size="sm" className="w-full justify-start gap-2 border-primary/20 hover:bg-primary/10">
                  <Link href="/login">
                    <LogIn className="h-4 w-4" />
                    <span>Log In</span>
                  </Link>
                </Button>
              ) : (
                <Button onClick={handleLogout} variant="ghost" size="sm" className="w-full justify-start gap-2 text-destructive hover:text-destructive hover:bg-destructive/10">
                  <LogOut className="h-4 w-4" />
                  <span>Logout</span>
                </Button>
              )}
            </div>
          </SidebarFooter>
        </Sidebar>

        <main className="flex-1 overflow-auto">
          <header className="no-print h-16 border-b bg-card flex items-center justify-between px-4 md:px-8 sticky top-0 z-30">
            <div className="flex items-center gap-2 md:gap-4">
              <SidebarTrigger className="md:hidden" />
              <h2 className="text-sm font-medium text-muted-foreground uppercase tracking-wider">
                {navItems.find(item => item.href === pathname)?.name || 'Dashboard'}
              </h2>
            </div>
            <div className="flex items-center gap-4">
              {isGuest && (
                <Button asChild variant="ghost" size="sm" className="hidden sm:flex text-primary">
                  <Link href="/login">Sign In</Link>
                </Button>
              )}
              <Button variant="ghost" size="icon" className="relative">
                <Bell className="h-5 w-5" />
                <span className="absolute top-2 right-2 h-2 w-2 bg-accent rounded-full border-2 border-card"></span>
              </Button>
              
              <div className="h-8 w-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold text-xs uppercase cursor-default">
                {userInitials}
              </div>
            </div>
          </header>
          <div className="p-4 md:p-8">
            {children}
          </div>
        </main>
      </div>

      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Edit Store Name</DialogTitle>
            <DialogDescription>
              Change how your store name appears in the dashboard and receipts.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="displayName">Store Name</Label>
              <Input
                id="displayName"
                value={newDisplayName}
                onChange={(e) => setNewDisplayName(e.target.value)}
                placeholder="Enter your store name..."
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSaveProfile} className="bg-primary">Save Changes</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </SidebarProvider>
  );
}
