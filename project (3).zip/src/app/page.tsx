'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useUser } from '@/firebase';

export default function Home() {
  const { user, loading } = useUser();
  const router = useRouter();

  useEffect(() => {
    // With the bypass, we always go to the dashboard once loading is done
    if (!loading) {
      router.push('/dashboard');
    }
  }, [user, loading, router]);

  return (
    <div className="flex items-center justify-center min-h-screen bg-background text-primary">
      <div className="flex flex-col items-center gap-4">
        <div className="h-12 w-12 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
        <p className="font-bold text-xl animate-pulse tracking-tight">Launching BillForge...</p>
      </div>
    </div>
  );
}
