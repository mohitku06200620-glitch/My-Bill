'use client';

import { useState, useEffect } from 'react';
import { User, onAuthStateChanged } from 'firebase/auth';
import { useAuth } from '../provider';

// Define a guest user that matches the Firebase User interface closely enough for the app
const GUEST_USER = {
  uid: 'guest-store-user',
  email: 'guest@billforge.app',
  displayName: 'Guest Store',
} as User;

export function useUser() {
  const auth = useAuth();
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!auth) {
      setUser(GUEST_USER);
      setLoading(false);
      return;
    }

    const unsubscribe = onAuthStateChanged(auth, (firebaseUser) => {
      // If Firebase auth gives us a user, use it. Otherwise, use our guest bypass.
      setUser(firebaseUser || GUEST_USER);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [auth]);

  const isGuest = user?.uid === 'guest-store-user';

  return { user, loading, isGuest };
}
