'use client';

import { FirestorePermissionError } from './errors';

type Listener = (error: FirestorePermissionError) => void;

class FirebaseErrorEmitter {
  private listeners: Set<Listener> = new Set();

  emit(event: 'permission-error', error: FirestorePermissionError): void {
    if (event === 'permission-error') {
      this.listeners.forEach((listener) => listener(error));
    }
  }

  on(event: 'permission-error', listener: Listener): void {
    if (event === 'permission-error') {
      this.listeners.add(listener);
    }
  }

  off(event: 'permission-error', listener: Listener): void {
    if (event === 'permission-error') {
      this.listeners.delete(listener);
    }
  }
}

export const errorEmitter = new FirebaseErrorEmitter();
