
'use client';

// Firebase configuration for the project
// Note: Ensure Email/Password sign-in is enabled in the Firebase Console:
// Authentication > Sign-in method > Add new provider > Email/Password
export const firebaseConfig = {
  apiKey: "AIzaSyB_fZAuEOR9dwGslTP-ajXicsGyza2N8W8",
  authDomain: "studio-7545740065-53c2c.firebaseapp.com",
  projectId: "studio-7545740065-53c2c",
  storageBucket: "studio-7545740065-53c2c.firebasestorage.app",
  messagingSenderId: "7545740065",
  appId: "1:7545740065:web:53c2c8f8b8e8d8c8b8a8z8"
};
